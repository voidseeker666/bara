`
Bara ( Creator )
Tama ( Friend )
zynxzo ( Friend )
Kiur ( Friend )
Dark Angel ( My Team )`
